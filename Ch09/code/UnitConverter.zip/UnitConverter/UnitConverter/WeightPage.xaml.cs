namespace UnitConverter;

public partial class WeightPage : ContentPage
{

    string[] availableUnits = { "Kilogram", "Gram", "Milligram", "Tonne", "Stone", "Pound", "Ounce" };
	public WeightPage()
	{
		InitializeComponent();
        sourcePicker.ItemsSource = availableUnits;
        sourcePicker.SelectedIndex = 0;
        targetPicker.ItemsSource = availableUnits;
        targetPicker.SelectedIndex = 1;
    }

    private void Button_Clicked(object sender, EventArgs e)
    {
        if (!String.IsNullOrWhiteSpace(sourceText.Text) && double.TryParse(sourceText.Text, out double sourceValue))
        {
            double resultValue = ConvertValue(sourceValue, sourcePicker.SelectedIndex, targetPicker.SelectedIndex);
            resultText.Text = $"Result:\n{resultValue}";
        }
        else
        {
            resultText.Text = "";
        }

    }

    private double ConvertValue(double sourceValue, int sourceIndex, int targetIndex)
    {
        double[] conversionFactors = { 1, 1000, 1000000, 0.001, 0.157473, 2.20462, 35.274 };
        return sourceValue * conversionFactors[targetIndex] / conversionFactors[sourceIndex];
    }
}