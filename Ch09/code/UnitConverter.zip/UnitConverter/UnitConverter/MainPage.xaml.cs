﻿namespace UnitConverter;

public partial class MainPage : ContentPage
{
	public MainPage()
	{
		InitializeComponent();
	}

    private async void lengthButton_Clicked(object sender, EventArgs e)
    {
		await Navigation.PushAsync(new LengthPage());

    }

    private async void weightButton_Clicked(object sender, EventArgs e)
    {
        await Navigation.PushAsync(new WeightPage());

    }

    private async void volumeButton_Clicked(object sender, EventArgs e)
    {
        await Navigation.PushAsync(new VolumePage()); 
    }

    private async void tempButton_Clicked(object sender, EventArgs e)
    {
        await Navigation.PushAsync(new TemperaturePage());

    }

    private async void areaButton_Clicked(object sender, EventArgs e)
    {
        await Navigation.PushAsync(new AreaPage());
    }

    private async void timeButton_Clicked(object sender, EventArgs e)
    {
        await Navigation.PushAsync(new TimePage());
    }
}
