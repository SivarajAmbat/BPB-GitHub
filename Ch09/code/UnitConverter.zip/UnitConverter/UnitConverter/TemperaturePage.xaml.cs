namespace UnitConverter;

public partial class TemperaturePage : ContentPage
{

    string[] availableUnits = { "Celsius", "Fahrenheit", "Kelvin" };
    public TemperaturePage()
    {
        InitializeComponent();
        sourcePicker.ItemsSource = availableUnits;
        sourcePicker.SelectedIndex = 0;
        targetPicker.ItemsSource = availableUnits;
        targetPicker.SelectedIndex = 1;
    }

    private void Button_Clicked(object sender, EventArgs e)
    {
        if (!String.IsNullOrWhiteSpace(sourceText.Text) && double.TryParse(sourceText.Text, out double sourceValue))
        {
            double resultValue = ConvertValue(sourceValue, sourcePicker.SelectedIndex, targetPicker.SelectedIndex);
            resultText.Text = $"Result:\n{resultValue}";
        }
        else
        {
            resultText.Text = "";
        }

    }

    private double ConvertValue(double sourceValue, int sourceIndex, int targetIndex)
    {
        if (sourceIndex == targetIndex)
        {
            return sourceValue;
        }

        switch (sourceIndex)
        {
            case 0: // Celsius
                return targetIndex == 1 ? (sourceValue * 9.0 / 5.0) + 32.0 : sourceValue + 273.15;
            case 1: // Fahrenheit
                return targetIndex == 0 ? (sourceValue - 32.0) * 5.0 / 9.0 : ((sourceValue - 32.0) * 5.0 / 9.0) + 273.15;
            case 2: // Kelvin
                return targetIndex == 0 ? sourceValue - 273.15 : ((sourceValue - 273.15) * 9.0 / 5.0) + 32.0;
            default:
                return sourceValue;
        }
    }
}