namespace UnitConverter;

public partial class AreaPage : ContentPage
{

    string[] availableUnits = { "Acre", "Square Meter", "Square Kilometre", "Hectare", "Square Mile", "Square Yard", "Square Foot", "Square Inch" };

    public AreaPage()
	{
		InitializeComponent();
        sourcePicker.ItemsSource = availableUnits;
        sourcePicker.SelectedIndex = 0;
        targetPicker.ItemsSource = availableUnits;
        targetPicker.SelectedIndex = 1;
    }

    private void Button_Clicked(object sender, EventArgs e)
    {
        if (!String.IsNullOrWhiteSpace(sourceText.Text) && double.TryParse(sourceText.Text, out double sourceValue))
        {
            double resultValue = ConvertValue(sourceValue, sourcePicker.SelectedIndex, targetPicker.SelectedIndex);
            resultText.Text = $"Result:\n{resultValue}";
        }
        else
        {
            resultText.Text = "";
        }

    }

    private double ConvertValue(double sourceValue, int sourceIndex, int targetIndex)
    {
        double[] conversionFactors = { 1, 4046.8564224, 0.0040468564, 0.4046856422, 0.0015624989, 4840, 43560, 6272640 };
        return sourceValue * conversionFactors[targetIndex] / conversionFactors[sourceIndex];
    }
}