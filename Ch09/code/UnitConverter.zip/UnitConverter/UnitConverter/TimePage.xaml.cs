namespace UnitConverter;

public partial class TimePage : ContentPage
{

    string[] availableUnits = { "Hour","Second", "Millisecond", "Microsecond", "Minute","Day", "Week", "Month", "Year" };

    public TimePage()
	{
		InitializeComponent();
        sourcePicker.ItemsSource = availableUnits;
        sourcePicker.SelectedIndex = 0;
        targetPicker.ItemsSource = availableUnits;
        targetPicker.SelectedIndex = 1;
    }

    private void Button_Clicked(object sender, EventArgs e)
    {
        if (!String.IsNullOrWhiteSpace(sourceText.Text) && double.TryParse(sourceText.Text, out double sourceValue))
        {
            double resultValue = ConvertValue(sourceValue, sourcePicker.SelectedIndex, targetPicker.SelectedIndex);
            resultText.Text = $"Result:\n{resultValue}";
        }
        else
        {
            resultText.Text = "";
        }

    }

    private double ConvertValue(double sourceValue, int sourceIndex, int targetIndex)
    {
        double[] conversionFactors = { 1, 3600, 3600000, 3600000000000, 60, 0.0416666667, 0.005952381, 0.0013689254, 0.0001140771 };
        return sourceValue * conversionFactors[targetIndex] / conversionFactors[sourceIndex];
    }
}