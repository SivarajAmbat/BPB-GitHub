namespace UnitConverter;

public partial class LengthPage : ContentPage
{
	string[] availableUnits = { "Meter", "Kilometre", "Centimetre", "Millimetre", "Mile", "Yard", "Foot", "Inch" };
	public LengthPage()
	{
		InitializeComponent();
		sourcePicker.ItemsSource = availableUnits;
		sourcePicker.SelectedIndex = 0;
		targetPicker.ItemsSource = availableUnits;
		targetPicker.SelectedIndex = 1;
	}

    private void Button_Clicked(object sender, EventArgs e)
    {
		if (!String.IsNullOrWhiteSpace(sourceText.Text) && double.TryParse(sourceText.Text, out double sourceValue))
		{
			double resultValue = ConvertValue(sourceValue, sourcePicker.SelectedIndex, targetPicker.SelectedIndex);
			resultText.Text = $"Result:\n{resultValue}";
		}
		else 
		{
			resultText.Text = "";
		}
    }

    private double ConvertValue(double sourceValue, int sourceIndex, int targetIndex)
    {
		double[] conversionFactors = { 1, 0.001, 100, 1000, 0.000621371, 1.09341, 3.28084, 39.3701};
		return sourceValue * conversionFactors[targetIndex] / conversionFactors[sourceIndex];
    }
}